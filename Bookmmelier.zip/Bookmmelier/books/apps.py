from django.apps import AppConfig


class booksConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'books'
